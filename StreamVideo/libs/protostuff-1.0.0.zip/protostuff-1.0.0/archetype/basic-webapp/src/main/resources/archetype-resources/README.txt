Requirements:

Running:
  $ mvn install
  $ cd server
  $ mvn jetty:run

Eclipse setup:
  $ mvn eclipse:eclipse

Rapid development setup:
  Use maven-jetty-plugin.
  $ mvn jetty:run

