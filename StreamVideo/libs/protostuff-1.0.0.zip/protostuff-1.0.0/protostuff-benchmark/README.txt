Running:
$ cd target
$ java -Dbenchmark.output_dir=. -jar protostuff-benchmark-1.0-SNAPSHOT-jar-with-dependencies.jar
